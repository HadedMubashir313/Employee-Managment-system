/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emsapp;

/**
 *
 * @author Hadia Haded Mubashir
 */
public class mdlEmployeeDetails {
    
        
    int ID;
    String name;
    String EmailAddress;
    int PhoneNumber;
    String Position;
    String Salary;
    String ProjectName;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public void setEmailAddress(String EmailAddress) {
        this.EmailAddress = EmailAddress;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(int PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getPosition() {
        return Position;
    }

    public void setPosition(String Position) {
        this.Position = Position;
    }

    public String getSalary() {
        return Salary;
    }

    public void setSalary(String Salary) {
        this.Salary = Salary;
    }

    public String getProjectName() {
        return ProjectName;
    }

    public void setProjectName(String ProjectName) {
        this.ProjectName = ProjectName;
    }

    public mdlEmployeeDetails(int ID, String name, String EmailAddress, int PhoneNumber, String Position, String Salary, String ProjectName) {
        this.ID = ID;
        this.name = name;
        this.EmailAddress = EmailAddress;
        this.PhoneNumber = PhoneNumber;
        this.Position = Position;
        this.Salary = Salary;
        this.ProjectName = ProjectName;
    }
    
}
