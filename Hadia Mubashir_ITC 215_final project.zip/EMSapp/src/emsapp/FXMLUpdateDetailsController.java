/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emsapp;


import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Hadia Haded Mubashir
 */
public class FXMLUpdateDetailsController implements Initializable {
    
      @FXML
      private TableView<mdlEmployeeDetails> tblUpdateDetails;

    @FXML
    private TableColumn<mdlEmployeeDetails, Integer> colIDU;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colNameU;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colEmailU;

    @FXML
    private TableColumn<mdlEmployeeDetails, Integer> colPhoneU;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colPosU;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colSalaryU;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colProjectU;

    @FXML
    private TextField txtIDU;

    @FXML
    private TextField txtPosU;

    @FXML
    private TextField txtNameU;

    @FXML
    private TextField txtEmailU;

    @FXML
    private TextField txtPhoneU;

    @FXML
    private TextField txtSalaryU;

    @FXML
    private TextField txtProjectU;

    @FXML
    private Button btnViewU;

    @FXML
    private Button btnBackU;

    @FXML
    private Button btnUpdate;

    @FXML
    private Label lblDirectionU;

   //Database Connection
      Connection conn;
      PreparedStatement pst;
      ResultSet resultSet;
      
      //connecting to dashbaord scene 

    @FXML
    void DashboardU(ActionEvent event) {
        
        try{
            Parent root = FXMLLoader.load(getClass().getResource("FXMLDash.fxml"));
            Scene scene = new Scene(root);
            Stage s = new Stage();
            s.setScene(scene);
            s.show();
        }catch(Exception ex){
            
        
        }

    }
    
    //allow updating records

    @FXML
    void UpdateRecords(ActionEvent event) {
        
       String uName = txtNameU.getText();
       String uEmail = txtEmailU.getText();
       String uPhone = txtPhoneU.getText();
       String uPosition = txtPosU.getText();
       String uSalary = txtSalaryU.getText();
       String uProject = txtProjectU.getText();
       
        databaseConnection dbconnect = new databaseConnection();
        
        //using index method to return index values
        int index = tblUpdateDetails.getSelectionModel().getSelectedIndex();
        int uID = colIDU.getCellData(index);
        
        
                String sql = "update currentemloyeeslist set NAME ='"+uName
                +"',EMAILADDRESS = '"+uEmail+"',PHONENUMBER ='"
                +uPhone+"',POSITION = '"+uPosition+"',SALARY ='"
                +uSalary+"',PROJECTNAME = '"+uProject+"' "
                +"where ID = '"+uID+"' ";
        if (databaseConnection.Action(sql)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Data Updated Successfully");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Failed");
            alert.showAndWait();
        }
        UpdateTableU();


    }
    //Views the employee's list

    @FXML
    void VeiwlistU(ActionEvent event) {
        
        ObservableList<mdlEmployeeDetails> list = databaseConnection.getEmployeesDetails();
        tblUpdateDetails.setItems(list);



    }
    
    //

    @FXML
    void selectRowU(MouseEvent event) {
        
                int index = tblUpdateDetails.getSelectionModel().getSelectedIndex();
        
                    txtIDU.setText(colIDU.getCellData(index).toString());
                    txtNameU.setText(colNameU.getCellData(index));
                    txtEmailU.setText(colEmailU.getCellData(index));
                    txtPhoneU.setText(colPhoneU.getCellData(index).toString());
                    txtPosU.setText(colPosU.getCellData(index));
                    txtSalaryU.setText(colSalaryU.getCellData(index));
                    txtProjectU.setText(colProjectU.getCellData(index));
    }

    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        UpdateTableU();
        
        
        // TODO
    }
    public void UpdateTableU(){
        
        
                colIDU.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, Integer> ("ID"));
                colNameU.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("Name"));
                colEmailU.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("EmailAddress"));
                colPhoneU.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, Integer> ("PhoneNumber"));
                colPosU.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("Position"));
                colSalaryU.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("Salary"));
                colProjectU.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("ProjectName"));
                
        ObservableList<mdlEmployeeDetails> list = databaseConnection.getEmployeesDetails();
        tblUpdateDetails.setItems(list);
    }    
    
}
