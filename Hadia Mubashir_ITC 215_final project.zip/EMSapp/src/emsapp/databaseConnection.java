package emsapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.management.Query;
import javax.swing.JOptionPane;

/**
 *
 * @author Hadia Haded Mubashir
 */
public class databaseConnection {

    String url= "jdbc:mysql://localhost:3306/employeemanagmentsystem";
    String user = "root";
    String pass = "";
    static Connection conn = null;
    static Statement statement = null;
    static PreparedStatement pst = null;
    static ResultSet resultSet = null;

   public databaseConnection(){

        try{

        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection(url , user, pass);

            System.out.println("connected!");

        }catch(Exception ex){

            JOptionPane.showMessageDialog(null, ex);
            }

    }

    public void createTableRegistration(){

        String Query = "CREATE TABLE IF NOT EXISTS `employeemanagmentsystem`.`currentemloyeeslist` ( "+
                        "`ID` int(20) AUTO_INCREMENT NOT NULL NOT NULL," +
                        "`NAME` varchar(50) COLLATE utf8_bin NOT NULL," +
                        "`PHONENUMBER` int (20) NOT NULL, " +
                        "`EMAILADDRESS` varchar(50) COLLATE utf8_bin NOT NULL, "+
                        "`SALARY` int (20) NOT NULL, " +
                        "`PROJECTNAME` varchar(50) COLLATE utf8_bin NOT NULL, "+
                        ") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;";
        try {
            statement = conn.createStatement();
            statement.execute(Query);
        } catch(Exception ex){
            System.err.println(ex.getMessage());
        }
    }

    public ResultSet Execute(String Query) {
        try {
            statement = conn.createStatement();
            resultSet = statement.executeQuery(Query);
        } catch (SQLException e) {
            System.out.println("Exception at ExecuteQuery:DBConnect" + e.getLocalizedMessage());
            return null;
        }
        return resultSet;
    }

    public static boolean Action(String Qu) {
        try {
            statement = conn.createStatement();
            statement.execute(Qu);
            return true;
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage(), "Error Occured", JOptionPane.ERROR_MESSAGE);
            System.out.println("Exception at ExecuteQuery:DBConnect" + ex.getLocalizedMessage());
            return false;
        }
    }

        static ObservableList<mdlEmployeeDetails> getEmployeesDetails() {
        ObservableList<mdlEmployeeDetails> list = FXCollections.observableArrayList();
        databaseConnection dbconnect = new databaseConnection();
        String sql = "select * from currentemloyeeslist";

         try{
            resultSet = dbconnect.Execute(sql);

             while(resultSet.next()){
                int ID = resultSet.getInt("ID");
                String name = resultSet.getString("NAME");
                String EmailAddress = resultSet.getString("EMAILADDRESS");
                int PhoneNumber = resultSet.getInt("PHONENUMBER");
                String Position = resultSet.getString("POSITION");
                String Salary = resultSet.getString("SALARY");
                String ProjectName = resultSet.getString("PROJECTNAME");

                mdlEmployeeDetails a = new mdlEmployeeDetails(ID , name, EmailAddress, PhoneNumber, Position, Salary, ProjectName);
                list.addAll(a);
         }
    } catch (SQLException ex){
        Logger.getLogger(databaseConnection.class.getName()).log(Level.SEVERE, null, ex);
        ex.printStackTrace();
         }
        return list;

        }
}