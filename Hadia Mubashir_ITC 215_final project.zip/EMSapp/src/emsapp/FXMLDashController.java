/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emsapp;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Hadia Haded Mubashir
 */
public class FXMLDashController  {
    
   @FXML
    private ImageView imgDashLogo;

    @FXML
    private Label lblDashTittle;

    @FXML
    private Label lblDashInstruction;

    @FXML
    private Button btnAddEmp;
    
    @FXML
    private AnchorPane anchAbout;


    @FXML
    private Button btnDelete;

    @FXML
    private Button btnUpdate;

    @FXML
    private Button btnViewList;

    @FXML
    private Label lbldashboard;
    
    @FXML
    private Button btnAbout;


//conneting to View list scene
    @FXML
    private void DisplayEmployeesList(ActionEvent event) {
             try{
            Parent root = FXMLLoader.load(getClass().getResource("FXMLViewList.fxml"));
            Scene scene = new Scene(root);
            Stage s = new Stage();
            s.setScene(scene);
            s.show();
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage(), "Error Occured", JOptionPane.ERROR_MESSAGE); 
        
        }

    }
    
    //conneting to about scene
    
    @FXML
     void OpenAboutScene(ActionEvent event) {
        
          try{
            Parent root = FXMLLoader.load(getClass().getResource("FXMLAbout.fxml"));
            Scene scene = new Scene(root);
            Stage s = new Stage();
            s.setScene(scene);
            s.show();
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage(), "Error Occured", JOptionPane.ERROR_MESSAGE);
            
        
        }

    }
     
    //conneting to add employee scene
     
     @FXML
       void AllowInsertionToList(ActionEvent event) {
         FXMLLoader loader = new FXMLLoader();
         loader.setLocation(getClass().getResource("/emsapp/FXMLAddRow.fxml"));
         try {
             loader.load();
         } catch (IOException e) {
             Logger.getLogger(FXMLAddRowController.class.getName()).log(Level.SEVERE, null, e);
         }

         Parent parent = loader.getRoot();
         Stage stage = new Stage();
         stage.setScene(new Scene(parent));
         stage.initStyle(StageStyle.UTILITY);
         stage.show();

    }

       //conneting to Record deletion scene
       
    @FXML
     void allowDeletion(ActionEvent event) {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/emsapp/FXMLDeletion.fxml"));
        try {
            loader.load();
        } catch (IOException e) {
            Logger.getLogger(FXMLAddRowController.class.getName()).log(Level.SEVERE, null, e);
        }

        Parent parent = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(parent));
        stage.initStyle(StageStyle.UTILITY);
        stage.show();

    }

     //conneting to allow update scene
     
    @FXML
     void allowUpdateToList(ActionEvent event) {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/emsapp/FXMLUpdateDetails.fxml"));
        try {
            loader.load();
        } catch (IOException e) {
            Logger.getLogger(FXMLAddRowController.class.getName()).log(Level.SEVERE, null, e);
        }

        Parent parent = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(parent));
        stage.initStyle(StageStyle.UTILITY);
        stage.show();


    }

    }

