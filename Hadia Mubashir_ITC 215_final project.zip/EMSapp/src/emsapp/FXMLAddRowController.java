/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emsapp;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import javax.swing.JOptionPane;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import javax.swing.*;

/**
 * FXML Controller class
 *
 * @author Hadia Haded Mubashir
 */
public class FXMLAddRowController implements Initializable {
    
    @FXML
    private TableView<mdlEmployeeDetails> TblView;

    @FXML
    private TableColumn<mdlEmployeeDetails, Integer> colIDAdd;

    @FXML
    private TableColumn<mdlEmployeeDetails,String > colNameAdd;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colEmailAdd;

    @FXML
    private TableColumn<mdlEmployeeDetails, Integer> colPhoneAdd;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colPosAdd;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colSalaryAdd;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colProjectAdd;
    
    @FXML
    private Button btnInsertB;

    @FXML
    private Button btnViewAdd;
    
    @FXML
    private Label lblTittleInsertion;
    
    @FXML
    private TextField txtIDA;

    @FXML
    private TextField txtProjectA;

    @FXML
    private TextField txtEmailA;

    @FXML
    private TextField txtNameA;

    @FXML
    private TextField txtPhoneA;

    @FXML
    private TextField txtSalaryA;

    @FXML
    private TextField txtPositionA;

    @FXML
    private Label lblDirectionA;

    
        
    
   //Database Connection
    databaseConnection db = new databaseConnection();
    Connection conn;
      PreparedStatement pst;
      ResultSet resultSet;


    //connecting scenes
    @FXML
    void BackToDashboardA(ActionEvent event) {
        
        try{
            Parent root = FXMLLoader.load(getClass().getResource("FXMLDash.fxml"));
            Scene scene = new Scene(root);
            Stage s = new Stage();
            s.setScene(scene);
            s.show();
        }catch(Exception ex){
        }
    }
 // viewing the employee's list using observable list
    @FXML
    void ViewListt(ActionEvent event) {
        try {
            ObservableList<mdlEmployeeDetails> list = databaseConnection.getEmployeesDetails();
            TblView.setItems(list);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage(), "Error Occured", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Enables adding new record
    @FXML
    void insertRecord(ActionEvent event) {
        String ID = null;
        String Name = txtNameA.getText();
        String Email = txtEmailA.getText();
        String Phone = txtPhoneA.getText();
        String Salary = txtSalaryA.getText();
        String Position = txtPositionA.getText();
        String Project = txtProjectA.getText();

        String sql = "insert into currentemloyeeslist VALUES (" +
                "" + ID  +
                ",'" +Name+
                "','" +Email+
                "','" +Phone+
                "','" +Salary+
                "','" +Position +
                "','" +Project +"')";

        db.Execute(sql);
        System.out.println(sql);

        if (databaseConnection.Action(sql)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Data Inserted Completed");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Failed");
            alert.showAndWait();
        }

    }
   

      

//highlighting and transfering data from table to text fields
    @FXML
    void selectRowI(MouseEvent event) {

    }



    /**
     * Initializes the controller class.
     * @param url
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
            UpdateTable();
    }
    
    //viewing newly added records 
    
    
        private void UpdateTable() {
                colIDAdd.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, Integer> ("ID"));
                colNameAdd.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("Name"));
                colEmailAdd.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("EmailAddress"));
                colPhoneAdd.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, Integer> ("PhoneNumber"));
                colPosAdd.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("Position"));
                colSalaryAdd.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("Salary"));
                colProjectAdd.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("ProjectName"));
                
            ObservableList<mdlEmployeeDetails> list = databaseConnection.getEmployeesDetails();
            TblView.setItems(list);
    
    }    



}
