/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emsapp;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Hadia Haded Mubashir
 */
public class FXMLDeletionController implements Initializable {


    @FXML
    private TableView<mdlEmployeeDetails> tblDeletion;

    @FXML
    private TableColumn<mdlEmployeeDetails, Integer> colIDD;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colNameD;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colEmailD;

    @FXML
    private TableColumn<mdlEmployeeDetails, Integer> colPhoneD;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colPosD;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colSalaryD;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colProjectD;

    @FXML
    private Button btnBackD;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnVeiwD;

    @FXML
    private Label lblTittleD;
    
     @FXML
    private TextField txtIDD;

    @FXML
    private TextField txtProjectD;

    @FXML
    private TextField txtEmailD;

    @FXML
    private TextField txtNameD;

    @FXML
    private TextField txtPhoneD;

    @FXML
    private TextField txtSalaryD;

    @FXML
    private TextField txtPositionD;
    
        
    
   //Database Connection
      Connection conn;
      PreparedStatement pst;
      ResultSet resultSet;
      
      //conneting to dashboard scene
    
    @FXML
    void BackToDashD(ActionEvent event) {
        
        try{
            Parent root = FXMLLoader.load(getClass().getResource("FXMLDash.fxml"));
            Scene scene = new Scene(root);
            Stage s = new Stage();
            s.setScene(scene);
            s.show();
        }catch(Exception ex){
            

    }


    }
    
    //viewing employee's list

    @FXML
    void ViewListD(ActionEvent event) {
        
        ObservableList<mdlEmployeeDetails> list = databaseConnection.getEmployeesDetails();
        tblDeletion.setItems(list);

    }
    
   @FXML
    void selectRowD(MouseEvent event) {
        
        int index = tblDeletion.getSelectionModel().getSelectedIndex();
        
                    txtIDD.setText(colIDD.getCellData(index).toString());
                    txtNameD.setText(colNameD.getCellData(index));
                    txtEmailD.setText(colEmailD.getCellData(index));
                    txtPhoneD.setText(colPhoneD.getCellData(index).toString());
                    txtPositionD.setText(colPosD.getCellData(index));
                    txtSalaryD.setText(colSalaryD.getCellData(index));
                    txtProjectD.setText(colProjectD.getCellData(index));
        
    }

    
      

    //allwoing record deletion
    
    @FXML
    void deleteRecord(ActionEvent event) {

        databaseConnection dbconnect = new databaseConnection();

        //using index method to return index values
        int index = tblDeletion.getSelectionModel().getSelectedIndex();
        int uID = colIDD.getCellData(index);

        String sql = "DELETE FROM `currentemloyeeslist` WHERE ID = " + uID;
        if (databaseConnection.Action(sql)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Data Deleted Successfully");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Failed");
            alert.showAndWait();
        }

           //updating table after deletion
           
           UpdateTableD();
    }    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
       UpdateTableD();
    }

    //viewing elements of table alighed with model
    private void UpdateTableD() {
        
                colIDD.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, Integer> ("ID"));
                colNameD.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("name"));
                colEmailD.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("EmailAddress"));
                colPhoneD.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, Integer> ("PhoneNumber"));
                colPosD.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("Position"));
                colSalaryD.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("Salary"));
                colProjectD.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String> ("ProjectName"));
                
                
        ObservableList<mdlEmployeeDetails> list = databaseConnection.getEmployeesDetails();
        tblDeletion.setItems(list);
        
  }
    }
    