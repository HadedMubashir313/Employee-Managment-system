/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emsapp;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Hadia Haded Mubashir
 */
public class FXMLViewListController implements Initializable {


    @FXML
    private TableView<mdlEmployeeDetails> TblView;

    @FXML
    private TableColumn<mdlEmployeeDetails, Integer> colIDV;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colNameV;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colEmailV;

    @FXML
    private TableColumn<mdlEmployeeDetails, Integer> colPhoneV;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colPositionV;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colSalaryV;

    @FXML
    private TableColumn<mdlEmployeeDetails, String> colProjectV;

    @FXML
    private Button btnBackV;


    @FXML
    private Label lblemp;

    @FXML
    private TextField txtSearchBar;

    @FXML
    private Button btnViewV;

    @FXML
    private Label lblDirectionU;

    //Connection to database

    Connection conn;
    PreparedStatement pst;
    ResultSet resultSet;

    ObservableList<mdlEmployeeDetails> dataList;

    //conneting to dashboard scene

    @FXML
    void BackToDashboardV(ActionEvent event) {

        try {
            Parent root = FXMLLoader.load(getClass().getResource("FXMLDash.fxml"));
            Scene scene = new Scene(root);
            Stage s = new Stage();
            s.setScene(scene);
            s.show();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage(), "Error Occured", JOptionPane.ERROR_MESSAGE);

        }


    }
//allow displaying list


    @FXML
    void ViewListV(ActionEvent event) {
        try {
            ObservableList<mdlEmployeeDetails> list = databaseConnection.getEmployeesDetails();
            TblView.setItems(list);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage(), "Error Occured", JOptionPane.ERROR_MESSAGE);
        }

    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        databaseConnection db = new databaseConnection();

        colIDV.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, Integer>("ID"));
        colNameV.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String>("name"));
        colEmailV.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String>("EmailAddress"));
        colPhoneV.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, Integer>("PhoneNumber"));
        colPositionV.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String>("Position"));
        colSalaryV.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String>("Salary"));
        colProjectV.setCellValueFactory(new PropertyValueFactory<mdlEmployeeDetails, String>("ProjectName"));
    }

    //allow user search through records

    private void SearchRecord() {


        dataList = databaseConnection.getEmployeesDetails();

        FilteredList<mdlEmployeeDetails> filteredList = new FilteredList<>(dataList, p -> true);

        txtSearchBar.textProperty().addListener((observable, oldValue, newValue) -> {

            filteredList.setPredicate(users -> {

                //check if vlaues exists on any colunm to return or not

                if (newValue == null || newValue.isEmpty()) {

                    return true;
                }

                String lowerCaseFilter = newValue.toLowerCase();


                if (users.getName().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }

                if (users.getEmailAddress().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }

                if (users.getPosition().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }

                if (users.getSalary().toLowerCase().contains(lowerCaseFilter)) {
                    return true;

                }
                if (users.getProjectName().toLowerCase().contains(lowerCaseFilter)) {
                    return true;

                }


                return false;


            });

        });

        SortedList<mdlEmployeeDetails> sortedList = new SortedList<>(filteredList);

        sortedList.comparatorProperty().bind(TblView.comparatorProperty());

        TblView.setItems(sortedList);


    }

}